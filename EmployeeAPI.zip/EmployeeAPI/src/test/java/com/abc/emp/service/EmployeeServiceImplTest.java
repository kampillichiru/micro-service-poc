package com.abc.emp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.abc.emp.dto.EmployeeDto;
import com.abc.emp.entity.Employee;
import com.abc.emp.exception.EmployeeNotFoundException;
import com.abc.emp.mapper.EmployeeMapper;
import com.abc.emp.repository.EmployeeRepository;

public class EmployeeServiceImplTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateEmployee() {
        EmployeeDto employeeDto = new EmployeeDto(1L, "John Doe", "IT");
        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        when(employeeRepository.save(any(Employee.class))).thenReturn(employee);

        EmployeeDto createdEmployee = employeeService.createEmployee(employeeDto);

        assertNotNull(createdEmployee);
        assertEquals(employeeDto.getName(), createdEmployee.getName());
    }

    @Test
    public void testGetEmployeeById_Success() throws EmployeeNotFoundException {
        Employee employee = new Employee(1L, "John Doe", "IT");
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));

        EmployeeDto employeeDto = employeeService.getEmployeeById(1L);

        assertNotNull(employeeDto);
        assertEquals(employee.getName(), employeeDto.getName());
    }

    @Test
    public void testGetEmployeeById_NotFound() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> {
            employeeService.getEmployeeById(1L);
        });
    }

    @Test
    public void testGetEmployees() {
        List<Employee> employees = Arrays.asList(
            new Employee(1L, "John Doe", "IT"),
            new Employee(2L, "Jane Smith", "HR")
        );
        when(employeeRepository.findAll()).thenReturn(employees);

        List<EmployeeDto> employeeDtos = employeeService.getEmployees();

        assertNotNull(employeeDtos);
        assertEquals(2, employeeDtos.size());
    }

    @Test
    public void testDeleteEmployee_Success() throws EmployeeNotFoundException {
        Employee employee = new Employee(1L, "John Doe", "IT");
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));
        doNothing().when(employeeRepository).deleteById(1L);

        employeeService.deleteEmployee(1L);

        verify(employeeRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testDeleteEmployee_NotFound() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> {
            employeeService.deleteEmployee(1L);
        });
    }

    @Test
    public void testUpdateEmployee_Success() throws EmployeeNotFoundException {
        EmployeeDto employeeDto = new EmployeeDto(1L, "John Doe", "IT");
        Employee employee = new Employee(1L, "John Doe", "IT");
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));
        when(employeeRepository.save(any(Employee.class))).thenReturn(employee);

        EmployeeDto updatedEmployee = employeeService.updateEmployee(employeeDto);

        assertNotNull(updatedEmployee);
        assertEquals(employeeDto.getName(), updatedEmployee.getName());
    }

    @Test
    public void testUpdateEmployee_NotFound() {
        EmployeeDto employeeDto = new EmployeeDto(1L, "John Doe", "IT");
        when(employeeRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> {
            employeeService.updateEmployee(employeeDto);
        });
    }
}
