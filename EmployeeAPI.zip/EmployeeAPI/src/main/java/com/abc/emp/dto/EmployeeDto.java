// The package declaration defines the namespace in which the class resides.
package com.abc.emp.dto;

// The EmployeeDto class is a simple POJO (Plain Old Java Object) used for transferring data.
public class EmployeeDto {

    // Fields to store employee data.
    private Long id;           // Employee ID
    private String name;       // Employee name
    private String department; // Employee department

    // Parameterized constructor to initialize the fields.
    public EmployeeDto(Long id, String name, String department) {
        super(); // Calls the superclass constructor (Object class in this case).
        this.id = id;
        this.name = name;
        this.department = department;
    }

    // Default constructor for creating an instance without initializing fields.
    public EmployeeDto() {

    }

    // Getter method for 'id'.
    public Long getId() {
        return id;
    }

    // Setter method for 'id'.
    public void setId(Long id) {
        this.id = id;
    }

    // Getter method for 'name'.
    public String getName() {
        return name;
    }

    // Setter method for 'name'.
    public void setName(String name) {
        this.name = name;
    }

    // Getter method for 'department'.
    public String getDepartment() {
        return department;
    }

    // Setter method for 'department'.
    public void setDepartment(String department) {
        this.department = department;
    }
}
