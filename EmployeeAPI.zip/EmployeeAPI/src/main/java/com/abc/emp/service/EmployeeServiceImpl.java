// The package declaration defines the namespace in which the class resides.
package com.abc.emp.service;

import java.util.List;                          // Importing the List interface from the Java Collections Framework.
import java.util.Optional;                      // Importing the Optional class to handle potentially null values.
import java.util.stream.Collectors;             // Importing the Collectors utility for processing streams.

import org.springframework.beans.factory.annotation.Autowired;   // Importing the Autowired annotation for dependency injection.
import org.springframework.stereotype.Service;                  // Importing the Service annotation to mark this class as a Spring service.

import com.abc.emp.dto.EmployeeDto;             // Importing the EmployeeDto class.
import com.abc.emp.entity.Employee;             // Importing the Employee entity class.
import com.abc.emp.exception.EmployeeNotFoundException; // Importing the custom exception class.
import com.abc.emp.mapper.EmployeeMapper;       // Importing the EmployeeMapper class.
import com.abc.emp.repository.EmployeeRepository; // Importing the EmployeeRepository interface.

// The @Service annotation marks this class as a Spring service component.
@Service
// The EmployeeServiceImpl class implements the EmployeeService interface, providing concrete implementations for its methods.
public class EmployeeServiceImpl implements EmployeeService {

    // The @Autowired annotation tells Spring to inject an instance of EmployeeRepository here.
    // This is dependency injection in action, making it easier to manage dependencies.
    @Autowired
    private EmployeeRepository employeeRepository;

    // Implementation of the createEmployee method.
    @Override
    public EmployeeDto createEmployee(EmployeeDto employeeDto) {
        // Convert the EmployeeDto to an Employee entity using the EmployeeMapper.
        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        // Save the Employee entity to the database and get the saved entity back.
        Employee createdEmployee = employeeRepository.save(employee);
        // Convert the saved Employee entity back to an EmployeeDto and return it.
        return EmployeeMapper.mapToEmployeeDto(createdEmployee);
    }

    // Implementation of the getEmployeeById method.
    @Override
    public EmployeeDto getEmployeeById(Long employeeId) throws EmployeeNotFoundException {
        // Retrieve an employee by ID. The result is wrapped in an Optional to handle null values.
        Optional<Employee> employee = employeeRepository.findById(employeeId);
        // If the employee is not found, throw a custom exception.
        if (employee.isEmpty()) {
            throw new EmployeeNotFoundException("Employee with id - " + employeeId + " not found.");
        }
        // Convert the found Employee entity to an EmployeeDto and return it.
        return EmployeeMapper.mapToEmployeeDto(employee.get());
    }

    // Implementation of the getEmployees method.
    @Override
    public List<EmployeeDto> getEmployees() {
        // Retrieve all employees from the database.
        List<Employee> employees = employeeRepository.findAll();
        // Convert the list of Employee entities to a list of EmployeeDto objects using streams and the EmployeeMapper.
        return employees.stream()
                        .map((emp) -> EmployeeMapper.mapToEmployeeDto(emp))
                        .collect(Collectors.toList());
    }

    // Implementation of the deleteEmployee method.
    @Override
    public void deleteEmployee(Long employeeId) throws EmployeeNotFoundException {
        // Retrieve the employee by ID.
        Optional<Employee> employee = employeeRepository.findById(employeeId);
        // If the employee is not found, throw a custom exception.
        if (employee.isEmpty()) {
            throw new EmployeeNotFoundException("Employee with id - " + employeeId + " not found.");
        }
        // If found, delete the employee by ID.
        employeeRepository.deleteById(employeeId);
    }

    // Implementation of the updateEmployee method.
    @Override
    public EmployeeDto updateEmployee(EmployeeDto employeeDto) throws EmployeeNotFoundException {
        // Retrieve the employee by ID.
        Optional<Employee> retrievedEmployee = employeeRepository.findById(employeeDto.getId());
        // If the employee is not found, throw a custom exception.
        if (retrievedEmployee.isEmpty()) {
            throw new EmployeeNotFoundException("Employee with id - " + employeeDto.getId() + " not found.");
        }
        // Update the employee's details with the information from the EmployeeDto.
        Employee employee = retrievedEmployee.get();
        employee.setName(employeeDto.getName());
        employee.setDepartment(employeeDto.getDepartment());
        // Save the updated employee to the database.
        Employee createdEmployee = employeeRepository.save(employee);
        // Convert the updated Employee entity back to an EmployeeDto and return it.
        return EmployeeMapper.mapToEmployeeDto(createdEmployee);
    }
}
