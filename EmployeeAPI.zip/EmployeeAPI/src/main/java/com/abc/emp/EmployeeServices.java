// The package declaration defines the namespace in which the class resides.
package com.abc.emp;

// Importing necessary Spring Boot classes.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// @SpringBootApplication is a convenience annotation that adds:
// - @Configuration: Tags the class as a source of bean definitions for the application context.
// - @EnableAutoConfiguration: Tells Spring Boot to start adding beans based on classpath settings, other beans, and various property settings.
// - @ComponentScan: Tells Spring to look for other components, configurations, and services in the com.abc.emp package.
@SpringBootApplication
public class EmployeeServices {

    // The main() method serves as the entry point for the Java application.
    public static void main(String[] args) {
        // SpringApplication.run() is a static method used to launch the Spring Boot application.
        SpringApplication.run(EmployeeServices.class, args);
    }

}
