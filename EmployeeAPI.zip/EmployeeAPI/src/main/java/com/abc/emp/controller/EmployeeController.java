// The package declaration defines the namespace in which the class resides.
package com.abc.emp.controller;

import java.util.List;

// Importing necessary Spring framework and other classes.
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.abc.emp.dto.EmployeeDto;
import com.abc.emp.exception.EmployeeNotFoundException;
import com.abc.emp.service.EmployeeService;

// @RestController is a specialized version of the @Controller annotation.
// It is a convenience annotation that combines @Controller and @ResponseBody, eliminating the need to annotate each method with @ResponseBody.
@RestController
public class EmployeeController {

    // @Autowired is used for automatic dependency injection.
    // It injects the EmployeeService bean into this controller.
    @Autowired
    private EmployeeService employeeService;

    // @PostMapping is a specialized version of @RequestMapping(method = RequestMethod.POST).
    // This method handles HTTP POST requests to create a new employee.
    @PostMapping(value = "/employee")
    public ResponseEntity<EmployeeDto> createEmployee(@RequestBody EmployeeDto employeeDto) {
        // The @RequestBody annotation indicates that the method parameter will be bound to the body of the HTTP request.
        EmployeeDto createdEmployee = employeeService.createEmployee(employeeDto);
        // ResponseEntity is a wrapper for an HTTP response, including status, headers, and body.
        return new ResponseEntity<>(createdEmployee, HttpStatus.CREATED);  // Returns HTTP status 201 (Created).
    }

    // @GetMapping is a specialized version of @RequestMapping(method = RequestMethod.GET).
    // This method handles HTTP GET requests to retrieve a list of all employees.
    @GetMapping(value = "/employees")
    public ResponseEntity<List<EmployeeDto>> getAllEmployees() {
        List<EmployeeDto> employees = employeeService.getEmployees();
        return new ResponseEntity<>(employees, HttpStatus.OK);  // Returns HTTP status 200 (OK).
    }

    // @GetMapping with a path variable to handle HTTP GET requests for a specific employee by ID.
    @GetMapping(value = "/employee/{id}")
    public ResponseEntity<EmployeeDto> getEmployeeById(@PathVariable("id") Long id) throws EmployeeNotFoundException {
        // The @PathVariable annotation indicates that the method parameter will be bound to a URI template variable.
        EmployeeDto employee = employeeService.getEmployeeById(id);
        return new ResponseEntity<>(employee, HttpStatus.OK);  // Returns HTTP status 200 (OK).
    }

    // @PutMapping is a specialized version of @RequestMapping(method = RequestMethod.PUT).
    // This method handles HTTP PUT requests to update an existing employee.
    @PutMapping(value = "/employee/{id}")
    public ResponseEntity<EmployeeDto> updateEmployee(@PathVariable("id") Long id, @RequestBody EmployeeDto employeeDto) throws EmployeeNotFoundException {
        EmployeeDto updatedEmployee = employeeService.updateEmployee(employeeDto);
        return new ResponseEntity<>(updatedEmployee, HttpStatus.OK);  // Returns HTTP status 200 (OK).
    }

    // @DeleteMapping is a specialized version of @RequestMapping(method = RequestMethod.DELETE).
    // This method handles HTTP DELETE requests to delete an existing employee.
    @DeleteMapping(value = "/employee/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable("id") Long id) throws EmployeeNotFoundException {
        employeeService.deleteEmployee(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);  // Returns HTTP status 204 (No Content).
    }
}
