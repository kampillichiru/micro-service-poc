// The package declaration defines the namespace in which the class resides.
package com.abc.emp.mapper;

import com.abc.emp.dto.EmployeeDto;    // Importing the EmployeeDto class.
import com.abc.emp.entity.Employee;    // Importing the Employee entity class.

// The EmployeeMapper class is responsible for converting between Employee entities and Employee DTOs.
public class EmployeeMapper {

    // This method maps an Employee entity to an EmployeeDto object.
    // It takes an Employee object as input and returns a new EmployeeDto object.
    public static EmployeeDto mapToEmployeeDto(Employee employee) {
        // Creates and returns a new EmployeeDto object using the data from the Employee entity.
        return new EmployeeDto(employee.getId(), employee.getName(), employee.getDepartment());
    }

    // This method maps an EmployeeDto object to an Employee entity.
    // It takes an EmployeeDto object as input and returns a new Employee entity object.
    public static Employee mapToEmployee(EmployeeDto employeeDto) {
        // Creates and returns a new Employee entity using the data from the EmployeeDto.
        return new Employee(employeeDto.getId(), employeeDto.getName(), employeeDto.getDepartment());
    }

}
