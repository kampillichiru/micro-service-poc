// The package declaration defines the namespace in which the interface resides.
package com.abc.emp.repository;

import org.springframework.data.jpa.repository.JpaRepository;  // Importing the JpaRepository interface from Spring Data JPA.
import com.abc.emp.entity.Employee;                       // Importing the Employee entity class.

// The EmployeeRepository interface extends JpaRepository, providing CRUD operations for the Employee entity.
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // No additional code is needed here. The JpaRepository interface provides all the necessary methods
    // for basic CRUD (Create, Read, Update, Delete) operations and more.
}
