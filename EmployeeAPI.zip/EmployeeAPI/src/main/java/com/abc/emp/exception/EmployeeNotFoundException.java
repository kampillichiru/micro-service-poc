// The package declaration defines the namespace in which the class resides.
package com.abc.emp.exception;

// The EmployeeNotFoundException class extends the Exception class, making it a custom checked exception.
public class EmployeeNotFoundException extends Exception {
    // serialVersionUID is a unique identifier for Serializable classes.
    // It is used during the deserialization process to verify that the sender and receiver of a serialized object maintain compatibility in terms of the object's class structure.
    private static final long serialVersionUID = 1L;

    // Default constructor for the exception.
    public EmployeeNotFoundException() {
    }

    // Constructor that accepts a custom error message.
    public EmployeeNotFoundException(String message) {
        // Calls the constructor of the superclass (Exception) with the provided error message.
        super(message);
    }
}
