package com.abc;

//Interface defining actions for vehicles
public interface VehicleActions {
 void displayInfo();
 double calculateFuelEfficiency(); // Returns fuel efficiency in appropriate units
 void applyBrakes(); // Simulates applying brakes
}
