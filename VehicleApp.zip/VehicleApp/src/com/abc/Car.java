package com.abc;

//Concrete class representing a Car, extending Vehicle
public class Car extends Vehicle {
	private int numberOfDoors;

	// Constructor using super to call parent class constructor
	public Car(String make, String model, int year, int numberOfDoors) {
		super(make, model, year);
		this.numberOfDoors = numberOfDoors;
	}

	// Overriding abstract method to display car details
	@Override
	public void displayInfo() {
		System.out.println(
				"Car: " + getMake() + " " + getModel() + " " + getYear() + " with " + numberOfDoors + " doors.");
	}

	public int getNumberOfDoors() {
		return numberOfDoors;
	}

	@Override
	public void start() {
		System.out.println("Car engine starts using push button:" + getModel());

	}

	@Override
	public void makeSound() {
		System.out.println("Car honks: Beep beep!");
	}
	  // Implementing calculateFuelEfficiency method for cars
    @Override
    public double calculateFuelEfficiency() {
        // Hypothetical calculation of fuel efficiency
        return 25.0; // Returns a dummy value for MPG
    }

    // Implementing applyBrakes method for cars
    @Override
    public void applyBrakes() {
        System.out.println("Applying brakes on the car.");
    }
}

