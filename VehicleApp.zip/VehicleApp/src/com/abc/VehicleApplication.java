package com.abc;

//Main application class to manage the vehicle system
public class VehicleApplication {
 public static void main(String[] args) {
     Vehicle car = new Car("Toyota", "Corolla", 2020, 4);
     Vehicle motorcycle = new Motorcycle("Harley-Davidson", "Sportster", 2019, false);

     car.displayInfo();
     car.start();
     car.applyBrakes(); // Simulate braking
     System.out.println("Fuel Efficiency: " + car.calculateFuelEfficiency());
     
     System.out.println("**********************************************");
     
     motorcycle.displayInfo();
     motorcycle.start();
     motorcycle.applyBrakes(); // Simulate braking
     System.out.println("Fuel Efficiency: " + motorcycle.calculateFuelEfficiency());

 }
}
