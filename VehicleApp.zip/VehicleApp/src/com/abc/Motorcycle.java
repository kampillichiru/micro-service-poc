package com.abc;

//Inheritance
//Concrete class representing a Motorcycle, extending Vehicle
public class Motorcycle extends Vehicle {
	private boolean hasSidecar;

	// Constructor using super to call parent class constructor
	public Motorcycle(String make, String model, int year, boolean hasSidecar) {
		super(make, model, year);
		this.hasSidecar = hasSidecar;
	}

	// Overriding abstract method to display motorcycle details
	@Override
	public void displayInfo() {
		System.out.println("Motorcycle: " + getMake() + " " + getModel() + " " + getYear()
				+ (hasSidecar ? " with sidecar." : " without sidecar."));
	}

	public boolean isHasSidecar() {
		return hasSidecar;
	}

	public void start() {
		System.out.println("Motorcycle engine kicks :" + getModel());

	}

	  // Implementing calculateFuelEfficiency method for motorcycles
    @Override
    public double calculateFuelEfficiency() {
        // Hypothetical calculation of fuel efficiency
        return 45.0; // Returns a dummy value for MPG
    }

    // Implementing applyBrakes method for motorcycles
    @Override
    public void applyBrakes() {
        System.out.println("Applying brakes on the motorcycle.");
    }

}
