package com.abc;

//Abstract class to represent a general Vehicle
public abstract class Vehicle {
	private String make;
	private String model;
	private int year;

	// Constructor to initialize vehicle properties
	public Vehicle(String make, String model, int year) {
		this.make = make;
		this.model = model;
		this.year = year;
	}

	// Getter methods
	public String getMake() {
		return make;
	}

	public String getModel() {
		return model;
	}

	public int getYear() {
		return year;
	}

	// Method to be overridden (Polymorphism)
	public void makeSound() {
		System.out.println("Vehicle makes a sound");
	}

	// Abstract method (Abstraction)
	// Abstract method to be implemented by subclasses
	public abstract void start();
	public abstract void displayInfo();
    public abstract double calculateFuelEfficiency();
    public abstract void applyBrakes(); 
}
